package com.d.uiautomatordemo;

import android.app.Instrumentation;
import android.content.Context;

import androidx.test.InstrumentationRegistry;
import androidx.test.runner.AndroidJUnit4;
import androidx.test.uiautomator.Configurator;
import androidx.test.uiautomator.UiDevice;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private Instrumentation mInstrumentation;
    private UiDevice mDevice;

    //执行任何Test函数之前会制动执行Before函数
    @Before
    public void setUp() {
        mInstrumentation = InstrumentationRegistry.getInstrumentation();
        mDevice = UiDevice.getInstance(mInstrumentation);
        Context context = InstrumentationRegistry.getContext();
        String pkName = context.getPackageName();
        Configurator configurator = Configurator.getInstance();
        long defalutWaitSelector = configurator.getWaitForSelectorTimeout();
        configurator.setWaitForSelectorTimeout(1000L);
        configurator.setActionAcknowledgmentTimeout(3000L);
        configurator.setScrollAcknowledgmentTimeout(3000L);
        configurator.setKeyInjectionDelay(100L);
    }
    //点击屏幕上像素坐标为(100,100)的位置,在函数名上右键选择debug click 即可运行
    @Test
    public void click(){
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        int xPos = 100,yPos = 100;
        mDevice.click(xPos,yPos);
    }
    //从下往上滑动屏幕
    @Test
    public void slideUp(){
        int endY = mDevice.getDisplayHeight()/8;
        int startY = mDevice.getDisplayHeight()*7/8;

        mDevice.swipe(mDevice.getDisplayWidth()/2,startY,mDevice.getDisplayWidth()/2,endY,20);
        try {
            int t = 500+(int)(Math.random()*1500);
            Thread.sleep(t);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
