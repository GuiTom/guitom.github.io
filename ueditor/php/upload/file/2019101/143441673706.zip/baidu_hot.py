from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException

import os


def start():

	cmd = 'chrome.exe --remote-debugging-port=9222 --user-data-dir="C:\\Users\\ChenChao\\selenium\\chrome1"'
	#打开调试状态的浏览器
	os.popen(cmd,'r',1)
	chrome_options = Options()
	chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
	chrome_driver = "D:\\Program Files\\chromedriver_win32\\chromedriver.exe"
	driver = webdriver.Chrome(chrome_driver, options=chrome_options)
	driver.get('http://top.baidu.com/buzz?b=1&fr=topbuzz_b1_c513')
	# page_source = driver.page_source
	# print(page_source)
	trTags = driver.find_elements_by_xpath('//tr[@class="hideline"]')#这是热搜前三名的特征xpath选择器
	print('len',len(trTags))
	for tr in trTags:
		print(tr.find_element_by_xpath('.//td[2]/a').text)
		
if __name__ == '__main__':
    start()